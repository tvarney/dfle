java -cp jar/DFDictionary.jar:jar/swing-layout-1.0.4.jar dfdictionary.DFDictionary
