#!/bin/bash
cp ../../dist/DFDictionary.jar DFDictionary.app/Contents/Resources/Java/
